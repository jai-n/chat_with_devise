// Define variables
var webSearch;
var lastSearch = 0;

chrome.tabs.getSelected(null, function(tab) {
    document.getElementById('currentLink').innerHTML = tab.url;
    
});

//Init function
$(function () { 
    webSearch = new google.search.WebSearch();
    webSearch.setSearchCompleteCallback(this, webSearchComplete, [webSearch, lastSearch]);

    $('#searchbox').focus();
});

// Begin search on keyup (realtime)
$('#searchbox').keyup(function () {
    var query = $(this).val();
    search(query);
});

// Search for the query 
function search(query) {
    if (query.length > 0) {
        $("#search-content").show();
    } else {
        $("#search-content").hide();
    }
    webSearch.execute(query);
}


function webSearchComplete(searcher, searchNum) {
    var contentDiv = document.getElementById('web-content');
    contentDiv.innerHTML = '';
    var results = searcher.results;
    var newResultsDiv = document.createElement('div');
    newResultsDiv.id = 'web-content';
    for (var i = 0; i < results.length; i++) {
        var result = results[i];
        var resultHTML = '<div style="height:70px; margin-top:5px;">';
        resultHTML += '<a href="' + result.unescapedUrl + '" target="_blank"><b>' + result.titleNoFormatting + '</b></a><br/>' + result.content + '<div/>';
        newResultsDiv.innerHTML += resultHTML;
    }
    contentDiv.appendChild(newResultsDiv);
}