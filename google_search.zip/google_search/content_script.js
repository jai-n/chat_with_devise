function myfunc(){
   var x = $('#options option:selected').text();
    //$("body").append('<div style="width:200px; height:200px; border: 1px solid red;"></div>');
   // $("body #rhs_block").html('<div style="width:200px; height:200px; border: 1px solid red;"></div>');
	//var div = document.getElementById('rhs_block');
	var div = $("#rhs_block");
	div.html("<div style='width:200px; height:200px; border: 1px solid red;'>hahahhaahahahha crack the <br> google result <br><b>jai lalawat</b></div>");

	console.log("i am getting now ..............................");
    //div.innerHTML = '<div style="width:200px; height:200px; border: 1px solid red;"></div>'+div.innerHTML + 'Extra stuff';
//    document.getElementById("rhs_block").innerHTML
}

$(document).ready(myfunc);